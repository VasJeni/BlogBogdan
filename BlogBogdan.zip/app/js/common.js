$(function() {

	// Custom JS

});
$(document).ready(function(){
    $(".lectures__images").owlCarousel({
        items: 1,
        loop : true,
        nav : true,
        dots : true,
        margin: 20
    });
    $(".sp__carousel").owlCarousel({
        items: 1,
        loop : true,
        nav : true,
        dots : true,
        margin : 20
    });
    $(".sp__carouse2").owlCarousel({
        items: 1,
        loop : true,
        nav : true,
        dots : true,
        margin : 20
    });
    $(".school__carousel").owlCarousel({
        items: 1,
        loop : true,
        nav : true,
        dots : true,
        margin : 20
    });
});
